#ifndef __PINFO_H__
#define __PINFO_H__

void exec_pinfo(int argc, char *argv[]);

#endif // __PINFO_H__
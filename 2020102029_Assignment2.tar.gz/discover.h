#ifndef __DISCOVER_H__
#define __DISCOVER_H__

void exec_discover(int argc, char *argv[]);
void recurse_search(char* target_dir,char* file_name,int flag_d,int flag_f);
#endif
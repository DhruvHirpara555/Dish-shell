#ifndef __SIGNALHANDLING_H__
#define __SIGNALHANDLING_H__


void sigint_handler(int sig);
void sigtstop_handler(int sig);
#endif
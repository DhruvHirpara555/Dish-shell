#ifndef __EXECUTE_H__
#define __EXECUTE_H__

void execute(int argc, char *argv[],int bp);
void execute_system(int argc, char *argv[],int bp);

#endif // __EXECUTE_H__

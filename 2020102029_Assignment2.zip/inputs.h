#ifndef __INPUTS_H__
#define __INPUTS_H__

char* get_input();
char** parse_input(char* comm, int* argc);

#endif
#ifndef __PROMPT_H
#define __PROMPT_H


extern char* home_dir;
extern unsigned int home_len;
void prompt();
void init_shell();

#endif
